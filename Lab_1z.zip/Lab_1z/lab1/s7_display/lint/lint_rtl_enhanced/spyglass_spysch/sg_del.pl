use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./lab1/s7_display/lint/lint_rtl_enhanced/spyglass_spysch/sg_msgtag.txt");
1;
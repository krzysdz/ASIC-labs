use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./lab1/s7_display/lint/lint_functional_rtl/spyglass_spysch/sg_msgtag.txt");
1;
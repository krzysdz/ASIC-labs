#!/bin/sh
cd /home/student/Documents/kdz/ASIC/Lab_1z
spyglass -project lab1.prj -goal lint/lint_functional_rtl & 
